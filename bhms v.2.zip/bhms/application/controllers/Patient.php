<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Users', 'user');
		$this->load->model('Announcement', 'announce');
	}

	public function index(){
		$this->check_access();
		$data['users'] = $this->user->read();
		$data['pagename'] = 'Patient';
		$data['contents'] = 'contents/patient';		
		$this->load->view('templates/patient', $data);
	}

	public function go_home(){
		$this->check_access();
		$data['posts'] = $this->announce->read();
		$data['pagename'] = 'Home';
		$data['contents'] = 'contents/home';		
		$this->load->view('templates/patient', $data);
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect('app');
	}


	private function check_access(){
		if($this->session->has_userdata('logged_in')){
			if($this->session->userdata('access_level') == 3){
				return true;
			}else{
				redirect('app');
			}
	    }else{
	    	redirect('app');
	    }
    }
	



}