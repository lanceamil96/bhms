
<?php
	$fname = $this->session->userdata('fname');
	$mi = $this->session->userdata('mi');
	$lname = $this->session->userdata('lname');
	$age = $this->session->userdata('age');
	$gender = $this->session->userdata('gender');
	$contact_no = $this->session->userdata('contact_no');
	$date_hired = $this->session->userdata('date_hired');
	
?>



<h3>Welcome <?= $this->session->userdata('username'); ?></h3>


<h4><?= $fname." ".$mi." ".$lname?></h4><br>
<h4><?= $age ?></h4><br>
<h4><?= $gender ?></h4><br>
<h4><?= $contact_no ?></h4><br>
<h4><?= $date_hired ?></h4><br>

