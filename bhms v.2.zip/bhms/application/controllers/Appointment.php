<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Appointment extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Appointment_Model', 'appointment');
	}
	public function index()
	{	
		$data['button'] = 'contents/bhw-button';
		$data['view'] = $this->appointment->getView();
		$data['list'] = $this->appointment->getIDtoList();
		// print_r($data['list']);
		
		$this->load->view('templates/bhw',$data);
		$this->load->view('pil/appointment_view');
	}
	public function add()
	{
		$data['button'] = 'contents/bhw-button';
		$this->load->view('templates/bhw',$data);
		$this->load->view('pil/appointment_add');
	}
	public function insert()
	{
		$data['button'] = 'contents/bhw-button';
		$this->load->view('templates/bhw',$data);
		$this->load->view('pil/insert');
		$this->load->view('pil/appointment_view');
	}
	public function showedit()
	{
		$data['button'] = 'contents/bhw-button';
		$this->load->view('templates/bhw',$data);
		$this->load->view('pil/appointment_edit');
	}
	public function edit()
	{
		$data['button'] = 'contents/bhw-button';
		$this->load->view('templates/bhw',$data);
		$this->load->view('pil/edit');
		$this->load->view('pil/appointment_view');
		// $this->load->view('welcome_message');
	}
	public function delete()
	{
		$data['button'] = 'contents/bhw-button';
		$this->load->view('templates/bhw',$data);
		$this->load->view('pil/delete');
		$this->load->view('pil/appointment_view');
	}
}