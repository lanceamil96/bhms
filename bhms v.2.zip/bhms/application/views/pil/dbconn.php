<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bhms') or die("Error connecting: ".mysqli_connect_error());
	// echo "Success";
 ?>