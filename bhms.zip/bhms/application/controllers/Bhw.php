<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bhw extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Users', 'user');
		$this->load->model('Announcement', 'announce');
	}

	public function index(){

		$this->check_access();
		$data['users'] = $this->user->read();
		$data['pagename'] = 'Bhw Dashboard';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/bhw';		
		$this->load->view('templates/bhw', $data);
	}

	public function go_home(){
		$this->check_access();
		$data['posts'] = $this->announce->read();
		$data['pagename'] = 'Home';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/home';		
		$this->load->view('templates/bhw', $data);
	}

	public function go_reg(){
		$data['pagename'] = 'Register Patient';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/reg';		
		$this->load->view('templates/bhw', $data);
	}

	public function go_announcement(){

		
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('details', 'Details', 'required');
		if($this->form_validation->run() == FALSE){
			$data['pagename'] = 'Announcements';
			$data['button'] = 'contents/bhw-button';
			$data['contents'] = 'contents/announcement';		
			$this->load->view('templates/bhw', $data);
		}else{

			$this->announce->create_announcement();

			redirect('bhw');
		}
		
	}

	

	private function check_access(){
		if($this->session->has_userdata('logged_in')){
			if($this->session->userdata('access_level') == 2){
				return true;
			}
			else{
				redirect('app');
			}
	    }else{
	    	redirect('app');
	    }
    }







	



}