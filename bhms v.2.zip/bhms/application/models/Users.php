<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Model {

    protected $table = "users";
    protected $table2 = "patient_records";

    public function __construct(){
		$this->load->database();
	}

   
    public function check_account($data){
    	$sql = "SELECT * FROM ".$this->table." WHERE username = '".$data['username']."' AND password = '".$data['password']."'";


    	return $this->db->query($sql)->result();
		
    	
		
    }

    public function get_precords($data = null){
    	$this->db->select('*');
		$this->db->from('patient p');
		$this->db->join('users u', 'p.user_id = u.user_id','left');
		$this->db->join('patient_records pr', 'p.precords_id = pr.precords_id','left');
		
		$this->db->where('u.user_id', $data[0]->user_id);
		$this->db->where('u.status = 2');

		$query = $this->db->get();
	
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}

    }

    public function get_erecords($data = null){
    	$this->db->select('*');
		$this->db->from('employee e');
		$this->db->join('users u', 'e.user_id = u.user_id','left');
		$this->db->join('employee_records er', 'e.erecords_id = er.erecords_id','left');
		
		$this->db->where('u.user_id', $data[0]->user_id);
		$this->db->where('u.status = 2');

		$query = $this->db->get();
	
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}

    }

    public function get_arecords($data = null){
    	$this->db->select('*');
		$this->db->from('employee e');
		$this->db->join('users u', 'e.user_id = u.user_id','left');
		$this->db->join('employee_records er', 'e.erecords_id = er.erecords_id','left');
		
		$this->db->where('u.user_id', $data[0]->user_id);
		$this->db->where('u.status = 1');

		$query = $this->db->get();
	
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}

    }

    


    public function read($id = null){
		if($id != null){
			$sql = "SELECT * FROM ".$this->table." WHERE user_id = ".$id;

			

			return $this->db->query($sql)->result();
		

		}

		$sql = "SELECT * FROM ".$this->table." WHERE status = '1' ";

		return $this->db->query($sql)->result();
		

		// return $this->db->get($this->table);

	}

	public function create_patient($data){

		$sql = "INSERT INTO ".$this->table2." (fname,lname,mi,age,gender,address,contact_no,birth_date,birth_place,mothers_name,fathers_name,birth_height,birth_weight) VALUES ('".$data['patientnamef']."','".$data['patientnamel']."','".$data['patientnamem']."','".$data['patientage']."','".$data['gender']."','".$data['address']."','".$data['contactnum']."','".$data['birthday']."','".$data['birthp']."','".$data['mothername']."','".$data['fathername']."','".$data['birthh']."','".$data['birthw']."')";

		echo $sql;
		return $this->db->query($sql);

		return $this->db->insert($data);

	}



}