<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_reg'); ?>">Register Patient</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('appointment'); ?>">Appointment</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_immunization'); ?>">Immunization</a>
</li>


<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_test'); ?>">Test</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_announcement'); ?>">Announcement</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('staff'); ?>">Staff</a>
</li>


<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_inventory'); ?>">View Inventory</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_reports'); ?>">Reports</a>
</li>