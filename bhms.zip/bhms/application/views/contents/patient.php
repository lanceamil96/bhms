<?php
	$fname = $this->session->userdata('fname');
	$mi = $this->session->userdata('mi');
	$lname = $this->session->userdata('lname');
	$age = $this->session->userdata('age');
	$gender = $this->session->userdata('gender');
	$address = $this->session->userdata('address');
	$contact_no = $this->session->userdata('contact_no');
	$mothers_name = $this->session->userdata('mothers_name');
	$fathers_name = $this->session->userdata('fathers_name');
	$birth_date = $this->session->userdata('birth_date');
	$birth_place = $this->session->userdata('birth_place');
	$birth_weight = $this->session->userdata('birth_weight');
	$birth_height = $this->session->userdata('birth_height');
	
?>



<h3>Welcome <?= $this->session->userdata('username'); ?></h3>


<h4><?= $fname." ".$mi." ".$lname?></h4><br>
<h4><?= $age?></h4><br>
<h4><?= $gender?></h4><br>
<h4><?= $address?></h4><br>
<h4><?= $contact_no?></h4><br>
<h4><?= $mothers_name?></h4><br>
<h4><?= $fathers_name?></h4><br>
<h4><?= $birth_date?></h4><br>
<h4><?= $birth_place?></h4><br>
<h4><?= $birth_weight?></h4><br>
<h4><?= $birth_height?></h4><br>
