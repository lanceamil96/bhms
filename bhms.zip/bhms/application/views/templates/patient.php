<html>
	<head>
		<title><?= $pagename.' : '; ?>BHMS</title>
		<link rel="stylesheet" href="<?=base_url('assets/bootstrap/bootstrap.min.css');?>">
		<link rel="stylesheet" href="<?=base_url('assets/css/style.css');?>">

		
		<script src="<?=base_url('assets/js/jquery.min.js');?>"></script>
		<script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
	</head>
	<body>
	
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  		<a class="navbar-brand" href="<?php echo base_url();?>">BHMS</a>
  

  		<div class="collapse navbar-collapse" id="navbarColor02">
		    <ul class="navbar-nav">
		    	<li class="nav-item">
		        	<a class="nav-link" href="<?= base_url('patient/go_home'); ?>">Home</a>
		     	</li>

		     	<li class="nav-item">
		        	<a class="nav-link" href="<?php echo base_url();?>">Change Password</a>
		     	</li>
	

		    	
		    </ul>
		</div>

		<div class="collapse navbar-collapse  " id="navbarColor02">
			<ul class="navbar-nav navbar-right">
		    	<li class="nav-item">
					<a class="nav-link" href="<?= base_url('patient/logout'); ?>">Logout</a>
				</li>
		    </ul>
		</div>
	</nav>

		<div class="post-panel">
			<?php 
				if(isset($contents)){
					$this->load->view($contents);
				}else{
					echo "No Page to Loads";
				}
			?>

		</div>

		  
    
  	

	</body>
</html>