
<?php echo validation_errors(); ?>
<?php echo form_open('bhw/go_announcement'); ?>
	<div class="form-group">
		<label>Title</label>
		<input type="text" name="title" class="form-control" placeholder="Add Title">
	</div>
	<div class="form-group">
		<label>Body</label>
		<textarea class="form-control" name="details" placeholder="Add Details"></textarea>
	</div>
	<button type="submit" class="btn btn-default">Submit</button>



</form>