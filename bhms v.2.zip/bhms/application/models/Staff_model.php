<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff_model extends CI_Model {
	public function __construct(){
		$this->load->database();
	}

	public function save_staff($data)
	{
		if($data['erecords_id']){
			$this->db->update('employee_records', $data ,array('erecords_id' => $data['erecords_id'] ));
		}
		else{
			$this->db->insert('employee_records', $data);
		}
	}

	public function getAll()
	{
		return $this->db->get('employee_records')->result();
	}

	public function get_info($id)
	{
		$this->db->where('erecords_id', $id);
		return $this->db->get('employee_records')->row();
	}

}