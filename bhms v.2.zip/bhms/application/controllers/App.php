<?php
defined('BASEPATH') OR exit('No direct script access allowed');


	class App extends CI_Controller {
		public function __construct(){
			parent::__construct();
			$this->load->model('Users', 'user');
			$this->load->model('Announcement', 'announce');
		}


		public function index(){
			$this->check_access();
			$data['posts'] = $this->announce->read();
			$data['pagename'] = 'Home';
			$data['button'] = 'contents/button';
			$data['contents'] = 'contents/home';
			$this->load->view('templates/main', $data);
		}

		public function view_announcement($id = null){
			$this->check_access();
			$data['announcement'] = $this->announce->view_post($id);
			$data['pagename'] = 'Home';
			$data['button'] = 'contents/button';
			$data['contents'] = 'contents/view_announcement';		
			$this->load->view('templates/main', $data);
	
		}

		public function go_home(){
			$this->check_access();
			$data['posts'] = $this->announce->read();
			$data['pagename'] = 'Home';
			$data['button'] = 'contents/button';
			$data['contents'] = 'contents/home';		
			$this->load->view('templates/main', $data);
		}

		public function go_login(){
			$data['pagename'] = 'Login';
			$data['contents'] = 'contents/login';		
			$this->load->view('templates/main', $data);
		}

		public function go_about(){
			$data['pagename'] = 'About';
			$data['button'] = 'contents/button';
			$data['contents'] = 'contents/about';		
			$this->load->view('templates/main', $data);
		}
		

		public function login(){
			$data = $this->input->post();
	
			$result = $this->user->check_account($data);
			

			if(count($result) && $result[0]->access_level == 1){
				$records = $this->user->get_arecords($result);
				$this->setSession_a($records);			
				redirect('dashboard');
			}else if(count($result) && $result[0]->access_level == 2){
				$records = $this->user->get_erecords($result);
				$this->setSession_e($records);			
				redirect('bhw');
			}else if(count($result) && $result[0]->access_level == 3){
				$records = $this->user->get_precords($result);
				$this->setSession_p($records);			
				redirect('patient');
			}else{
				redirect('app');
			}

		}

		public function registration(){

			$data = $this->input->post();
			foreach ($data as $key => $value) {
				echo $value;
			}

			$result = $this->validate($data); // return array of error messages
		
			redirect('app');
		}
		
			
		

		public function logout(){
			$this->session->sess_destroy();
			redirect('app');
		}

		private function setSession_p($data){
			$sessionData = array(
				'user_id' => $data[0]->user_id,
			    'username'  => $data[0]->username,
			    'access_level' => $data[0]->access_level,
			    'fname'  => $data[0]->fname,
			    'lname'  => $data[0]->lname,
			    'mi'  => $data[0]->mi,
			    'gender'  => $data[0]->gender,
			    'age'  => $data[0]->age,
			    'address'  => $data[0]->address,
			    'contact_no'  => $data[0]->contact_no,
			    'mothers_name'  => $data[0]->mothers_name,
			    'fathers_name'  => $data[0]->fathers_name,
			    'birth_date'  => $data[0]->birth_date,
			    'birth_place'  => $data[0]->birth_place,
			    'birth_weight'  => $data[0]->birth_weight,
			    'birth_height'  => $data[0]->birth_height,
			    
			    'logged_in' => TRUE
			);

			$this->session->set_userdata($sessionData);
		}

		private function setSession_e($data){
			$sessionData = array(
				'user_id' => $data[0]->user_id,
			    'username'  => $data[0]->username,
			    'access_level' => $data[0]->access_level,
			    'fname'  => $data[0]->fname,
			    'lname'  => $data[0]->lname,
			    'mi'  => $data[0]->mi,
			    'gender'  => $data[0]->gender,
			    'age'  => $data[0]->age,
			    'contact_no'  => $data[0]->contact_no,
			    'date_hired'  => $data[0]->date_hired,
			    
			    
			    'logged_in' => TRUE
			);

			$this->session->set_userdata($sessionData);
		}

		private function setSession_a($data){
			$sessionData = array(
				'user_id' => $data[0]->user_id,
			    'username'  => $data[0]->username,
			    'access_level' => $data[0]->access_level,
			    'fname'  => $data[0]->fname,
			    'lname'  => $data[0]->lname,
			    'mi'  => $data[0]->mi,
			    'gender'  => $data[0]->gender,
			    'age'  => $data[0]->age,
			    'contact_no'  => $data[0]->contact_no,
			    'date_hired'  => $data[0]->date_hired,
			    
			    
			    'logged_in' => TRUE
			);

			$this->session->set_userdata($sessionData);
		}


		private function check_access(){
			if($this->session->has_userdata('logged_in')){
				if($this->session->userdata('access_level') == 1){
					redirect('dashboard');
				}else if($this->session->userdata('access_level') == 2){
					redirect('bhw');
				}else if($this->session->userdata('access_level') == 3){
					redirect('patient');
				}
			}else{
				return true;
			}
		}


		private function validate($data){
		
			$err_msg = []; 
			

			if($data['patientnamel'] == ''){
				array_push($err_msg, "Patient's Last Name is not define");
			}

			if($data['patientnamem'] == ''){
				array_push($err_msg, "Patient's Middle Name is not define");
			}

			if($data['patientage'] == ''){
				array_push($err_msg, "Patient's Age is not define");
			}

			if($data['gender'] == ''){
				array_push($err_msg, "Patient's Gender is not define");
			}

			if($data['address'] == ''){
				array_push($err_msg, "Patient's Address is not define");
			}

			if($data['contactnum'] == ''){
				array_push($err_msg, "Patient's Contact Number is not define");
			}

			if($data['birthday'] == ''){
				array_push($err_msg, "Patient's Birthday is not define");
			}

			if($data['birthp'] == ''){
				array_push($err_msg, "Patient's Birthp is not define");
			}
			if($data['mothername'] == ''){
				array_push($err_msg, "Patient's Mother's Name is not define");
			}
			if($data['fathername'] == ''){
				array_push($err_msg, "Patient's Father's Name is not define");
			}

			if($data['birthh'] == ''){
				array_push($err_msg, "Patient's Birth Height is not define");
			}

			if($data['birthw'] == ''){
				array_push($err_msg, "Patient's Birth Weight is not define");
			}

			return $err_msg;
	}
		
	




	

	}