
<div id = "main-container">



<link rel="stylesheet" type="text/css"  href="<?php echo base_url(); ?>css/style.css">

<div class="panel-primary text-center">
	<h4><?= $pagename; ?></h4>
</div>

<div class="container col-md-6">
	<form action="<?= base_url('app/registration'); ?>" method="POST">
		<div class="panel-default">
			<div class="panel-body">
				<?php 
					if($this->session->flashdata('error_msg') != null){
						$msg = $this->session->flashdata('error_msg');
						$newMsg = "";
						foreach($msg as $key => $val){
							$newMsg .= $val."<br>";
						}
				?>
					<div class="alert alert-danger alert-dismissible" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					  
					
				<?php 
					   echo $newMsg;
				?>
					</div>
				<?php 
					}
				?>
					<div class="form-group">
			          	<input class="form-control" name="patientnamef" id="patientnamef" type="text" placeholder="First Name" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="patientnamel" id="patientnamel" type="text" placeholder="Last Name" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="patientnamem" id="patientnamem" type="text" placeholder="Middle Name" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="patientage" id="patientage" type="text" placeholder="Age" required>
			        </div>

			        <div class="form-group">
			        	
			        	<?php
			        		$options = array(
			        			""=>"Choose gender",
			        			"male"=>"Male",
			        			"female"=>"Female"
			        		);
			        	?>
			        	<?php echo form_dropdown('gender', $options,set_value('gender'),array("class"=>"form-control","id" => "gender")); ?>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="address" id="address" type="text" placeholder="Address" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="contactnum" id="contactnum" type="text" placeholder="Contact Number" required>
			        </div>

			         
			</div>
		</div>
	<!-- </form> -->

	<!-- <form action="<?= base_url('app/registration'); ?>" method="POST"> -->

			<div class="panel-body">
				<?php 
					if($this->session->flashdata('error_msg') != null){
						$msg = $this->session->flashdata('error_msg');
						$newMsg = "";
						foreach($msg as $key => $val){
							$newMsg .= $val."<br>";
						}
				?>
					<div class="alert alert-danger alert-dismissible" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					  
					
				<?php 
					   echo $newMsg;
				?>
					</div>
				<?php 
					}
				?>

					
			        <div class="form-group">
			          	<input class="form-control" name="birthday" id="birthday" type="Date" placeholder="Date of birth (mm/dd/yy)" required>
			        </div>

			         <div class="form-group">
			          	<input class="form-control" name="birthp" id="birthp" type="text" placeholder="Birth Place" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="mothername" id="mothername" type="text" placeholder="Mother's Name" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="fathername" id="fathername" type="text" placeholder="Father's Name" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="birthh" id="birthh" type="text" placeholder="Birth Height" required>
			        </div>

			        <div class="form-group">
			          	<input class="form-control" name="birthw" id="birthw" type="text" placeholder="Birth Weight" required>
			        </div>
			         
			         <div>
			          <button class="btn btn-primary" name="register" type="submit">Register <span class="glyphicon glyphicon-save"></span></p></button>         
			        </div>
			</div>
	</form>
</div>
</div>
</div>
