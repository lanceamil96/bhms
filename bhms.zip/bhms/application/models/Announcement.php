<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Announcement extends CI_Model {


	public function __construct(){
		$this->load->database();
	}


	public function read(){
		$this->db->select('*');
		$this->db->from('announcement a');
		$this->db->join('announcement_details b', 'b.ad_id = a.ad_id','left');
		$this->db->join('announcement_type c', 'c.at_id = a.at_id','left');
		$this->db->where('a.status', 1);
		$this->db->order_by('a.a_id','desc');
		$query = $this->db->get();
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}
	}

	public function create_announcement(){
		$title = $this->input->post('title');
		$details = $this->input->post('details');
	

		$data2 = array(
			'details' => $details
		);
		

		$this->db->insert('announcement_details', $data2);
		$detail_id = $this->db->insert_id();

		$data1 = array(
			'ad_id' => $detail_id,
			'title' => $title
			
		);


		return $this->db->insert('announcement', $data1);
		

	}





}