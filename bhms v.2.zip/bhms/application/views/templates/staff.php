<html>
	<head>
		<title><?= $pagename.' : '; ?>BHMS</title>
		<link rel="stylesheet" href=" <?=base_url('assets/bootstrap/bootstrap.min.css');?>">
		<link rel="stylesheet" href="<?=base_url('assets/css/style.css');?>">

		
		<script src="<?=base_url('assets/js/jquery.min.js');?>"></script>
		<script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
	</head>
	<body>
	
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  		<a class="navbar-brand" href="<?php echo base_url();?>">BHMS</a>
  

  		<div class="collapse navbar-collapse" id="navbarColor02">
		    <ul class="navbar-nav">
		    	<li class="nav-item">
		        	<a class="nav-link" href="<?= base_url('dashboard/go_home'); ?>">Home</a>
		     	</li>
					<?php 
					if(isset($button)){
						$this->load->view($button);
					}
				?>
		    </ul>
		</div>

		



		<div class="collapse navbar-collapse" id="navbarColor02">
			<ul class="navbar-nav navbar-right">
		    	<li class="nav-item">
					<a class="nav-link" href="<?= base_url('app/logout'); ?>">Logout</a>
				</li>
		    </ul>
		</div>


	</nav>

	<div class="post-panel">
		<form role="form" method="post" action="<?php echo site_url('staff/save_staff');?>">
		  <input type="hidden" name="erecords_id" id="erecords_id">
		  <div class="form-row">
		    <div class="form-group col-md-6">
		      <label for="inputEmail4">First Name</label>
		      <input type="text" class="form-control" id="fname" name="fname" required>
		    </div>
		    <div class="form-group col-md-6">
		      <label for="inputPassword4">Age</label>
		      <input type="text" class="form-control" id="age" name="age">
		    </div>
		  </div>
		   <div class="form-row">
		    <div class="form-group col-md-6">
		      <label for="inputEmail4">Last Name</label>
		      <input type="text" class="form-control" id="lname" name="lname">
		    </div>
		    <div class="form-group col-md-6">
		      <label for="inputPassword4">Gender</label>
		      <input type="text" class="form-control" id="gender" name="gender">
		    </div>
		  </div>
		  <div class="form-row">
		    <div class="form-group col-md-6">
		      <label for="inputEmail4">Middle Name</label>
		      <input type="text" class="form-control" id="mi" name="mi">
		    </div>
		    <div class="form-group col-md-6">
		      <label for="inputEmail4">Contact No.</label>
		      <input type="text" class="form-control" id="contact_no" name="contact_no">
		    </div>
		    <div class="form-group col-md-6">
		      <label for="inputPassword4">Address</label>
		       <textarea class="form-control" rows="5" id="address" name="address"></textarea>
		    </div>
		  </div>
		  <button type="submit" class="btn btn-primary">Save</button>
		  <button id="btn_reset" type="button" class="btn btn-danger" style="display: none;">Reset</button>
		</form>

		<br>
		<table class="table">
			<thead>
				<tr>
					<th scope="col" style="width: 10%">Staff ID</th>
					<th scope="col">Staff Name</th>
					<th scope="col">Age</th>
					<th scope="col" style="width: 10%">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
					foreach ($emp as $staff)
					{
					    echo "<tr>";
					    	echo "<td>";
					    		echo $staff->erecords_id;
					    	echo "</td>";

					    	echo "<td>";
					    		echo $staff->fname;
					    	echo "</td>";

					    	echo "<td>";
					    		echo $staff->age;
					    	echo "</td>";

					    	
					    	echo "<td><button class='action_edit btn btn-primary' id=$staff->erecords_id>Edit</button></td>";
					    echo "</tr>";
					}
				?>
			</tbody>
		</table>
	</div>
<script>

function reset(){
	$('#erecords_id').val("");
	$('form').find("input[type=text], textarea").val("");
	$('#btn_reset').attr('style','display: none;')
}

function button_event(){
	$('.action_edit').on('click', function(e){
		$.ajax({
			url: "<?php echo base_url(); ?>" + "staff/get_info/"+ this.id,
			method: 'POST',
			success: function(result){
				result = JSON.parse(result)

				$('#erecords_id').val(result.erecords_id);
				$('#fname').val(result.fname);
				$('#lname').val(result.lname);
				$('#mi').val(result.mi);
				$('#age').val(result.age);
				$('#gender').val(result.gender);
				$('#address').val(result.address);
				$('#contact_no').val(result.contact_no);

				$('#btn_reset').attr('style','display: block;')
				$("html, body").animate({ scrollTop: 0 }, "slow");
			}
		});
	});
}

	$("form").on('submit', function(e){
		e.preventDefault();
		var data = {};

		$("input").each(function() {
		    data[$(this).attr("name")] = $(this).val();
		});

		$.ajax({
			url: "<?php echo base_url(); ?>" + "staff/save_staff",
			method: 'POST',
			data: data,
			success: function(result){
				result = JSON.parse(result)
				$("table").find("tr:gt(0)").remove();

				for(x=0;x<result.length;x++){
					$('table tr:last').after('<tr><td>'+ result[x].erecords_id +'</td><td>'+ result[x].fname +'</td><td><button class="action_edit" id='+ result[x].age+ result[x].erecords_id +'>Edit</button></td></tr>' );
				}
				alert("success!");
				button_event();
				reset();
			}
		});
	});
	

	$("#btn_reset").click(function() {
	    reset();
	});

	button_event();

</script>
</body>
</html>