<?php 
	function display_data($data) {
		// var_dump($data);
	    $output = "<table>";
	    foreach($data as $key => $var) {
	        //$output .= '<tr>';
	        if($key===0) {
	            $output .= '<tr>';
	            foreach($var as $col => $val) {
	                $output .= "<td> " . $col . '</td>';
	            }
	            $output .= '</tr>';
	            foreach($var as $col => $val) {
	                $output .= '<td> ' . $val . '</td>';
	            }
	            $output .= '</tr>';
	        }
	        else {
	            $output .= '<tr>';
	            foreach($var as $col => $val) {
	                $output .= '<td> ' . $val . '</td>';
	            }
	            $output .= '</tr>';
	        }
	    }
	    $output .= '</table>';
	    echo $output;
	}

	require 'dbconn.php';
	$query = "SELECT * FROM appointment_view_all ORDER BY `Apt No.` ASC";
	$result = mysqli_query($conn, $query);
	// var_dump($view);
	display_data($view); //display_data ang function nga mag table sa values sa appointment_view_all nga view
 ?>
 <form action="showedit" method="post">
<?php 
$select= '<select name="Apt_ID" id="Apt_ID">';
// print_r($list);
$i = 0;
	    foreach($list as $key => $var) {
	        if($key===0) {
	            foreach($var as $col => $val) {
	            	if($i==0){
					$select.='<option value="" selected disabled hidden> Select row to edit: </option>';
	                $select.='<option value="'.$val.'">'.$val.'</option>';
	            	}else{
	                $select.='<option value="'.$val.'">'.$val.'</option>';
	            	}
	            }
	        }
	        else {
	            foreach($var as $col => $val) {
	                $select.='<option value="'.$val.'">'.$val.'</option>';
	            }
	        }
	    }
$select.='</select>';
echo $select; ?>
<input type="submit" name="submit" value="Edit"/>
</form>
<!-- <br> -->
 <form action="delete" method="post">
<?php 
$select= '<select name="Apt_ID" id="Apt_ID">';
// print_r($list);
$i = 0;
	    foreach($list as $key => $var) {
	        if($key===0) {
	            foreach($var as $col => $val) {
	            	if($i==0){
					$select.='<option value="" selected disabled hidden> Select row to delete: </option>';
	                $select.='<option value="'.$val.'">'.$val.'</option>';
	            	}else{
	                $select.='<option value="'.$val.'">'.$val.'</option>';
	            	}
	            }
	        }
	        else {
	            foreach($var as $col => $val) {
	                $select.='<option value="'.$val.'">'.$val.'</option>';
	            }
	        }
	    }
$select.='</select>';
echo $select; ?>
<input type="submit" name="submit" value="Delete"/>
</form>
<form action="add" method="post">
	<input type="submit" name="submit" value="Add">
</form>