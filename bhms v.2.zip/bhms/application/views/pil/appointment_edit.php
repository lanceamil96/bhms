<?php 
	require "dbconn.php";
	$Apt_Id = $this->input->post('Apt_ID');
	//echo $Apt_Id;
	$query = 'SELECT `appointment`.`apt_id`, `appointment`.`priority_no` AS `Priority No.`, `patient_records`.`fname` AS `Patient Name`, `employee_records`.`fname` AS `Employee Name`, `station`.`stname` AS `Station`, `medication_type`.`medication_type` AS `Medication Type`, `appointment`.`apt_date` AS `Date` FROM ((((((`appointment` JOIN `patient` ON ((`appointment`.`patient_id` = `patient`.`patient_id`))) JOIN `patient_records` ON ((`patient_records`.`precords_id` = `patient`.`patient_id`))) JOIN `employee` ON ((`appointment`.`emp_id` = `employee`.`emp_id`))) JOIN `employee_records` ON ((`employee`.`erecords_id` = `employee_records`.`erecords_id`))) JOIN `station` ON ((`appointment`.`station_id` = `station`.`station_id`))) JOIN `medication_type` ON ((`appointment`.`mtype_id` = `medication_type`.`mtype_id`))) WHERE apt_id=1';
     $Query_result = mysqli_query($conn, $query);
    // var_dump($Query_result);
     $result = $Query_result->fetch_assoc();
     $apt_id = $result['apt_id'];
     $pfname = $result['Patient Name'];
     $efname = $result['Employee Name'];
     $station = $result['Station'];
     $mtype = $result['Medication Type'];
     $queue = $result['Priority No.'];
 ?>
<!-- <option selected="selected" selected diabled hidden></option> -->
<!DOCTYPE html>
<html>
<head>
	<title>Appointment</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">

  <script src="assets/js/jquery-1.10.1.min.js"></script>
  <script src="assets/js/bootstrap.min.js" ></script>
  

	<style>
	

	img {float: left; margin-top: 0px; padding-top: 0px;}

	h1   {text-align: center; padding-left: 0px; margin-right: 180px; margin-top: 50px;}
	.form-group{padding: 15px; font-size: 20px; }
	#QueueInput {margin-left: 990px;}
	#submit {margin-left: 1100px; padding: 10px;}
</style>
</head>
<body>

	<form role="form" action="edit" method="post">
	<div><h1>Edit Appointment</h1><br><br>
		<input type="" name="Apt_Id" id="Apt_Id" value="<?php echo $Apt_Id ?>" hidden>
		<div id="QueueInput">
			
				Queue
				<input  type="text" id="Queue"name="Queue" value="<?php echo $queue ?>"><br>
			
		</div>

		<div class= "form-group" >
			<label>Patient Name:</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT * FROM patient_records";
			$select= '<select name="PName" id="PName">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				if($pfname==$rs['fname']){
					$select.='<option value="'.$rs['precords_id'].'" selected>'.$rs['fname'].' '.$rs['lname'].'</option>';
				}
				else{
				$select.='<option value="'.$rs['precords_id'].'">'.$rs['fname'].' '.$rs['lname'].'</option>';}
			}
			$select.='</select>';
			echo $select; ?>
			<br>
			<!-- Medication Select Input -->
			<label for="sel1">Medication:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT * FROM medication_type";
			$select= '<select name="medication" id="medication">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				if($mtype==$rs['medication_type']){
					$select.='<option value="'.$rs['mtype_id'].'" selected>'.$rs['medication_type'].'</option>';
				}
				else{
					$select.='<option value="'.$rs['mtype_id'].'">'.$rs['medication_type'].'</option>';
				}
			}
			$select.='</select>';
			echo $select; ?>
			<br>

			

			 <!-- Station Select Input -->
			<label for="sel2">Station:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT station_id,stname FROM station";
			$select= '<select name="station" id="station">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				if($station==$rs['stname']){
				$select.='<option value="'.$rs['station_id'].'" selected>'.$rs['stname'].'</option>';
			}else{
				$select.='<option value="'.$rs['station_id'].'">'.$rs['stname'].'</option>';
			}
			}
			$select.='</select>';
			echo $select; ?>
			      <br>

			<!-- Test Select Input -->
			<label for="sel3">Test:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT * FROM test_type";
			$select= '<select name="Test" id="Test">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				$select.='<option value="'.$rs['ttype_id'].'">'.$rs['test_type'].'</option>';
			}
			$select.='</select>';
			echo $select; ?>
	<hr>

			  <!-- Station Select Input -->
			<label for="sel4">Assigned Staff:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT erecords_id,fname,lname FROM employee_records";
			$select= '<select name="staff" id="staff">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				if($pfname==$rs['fname']){
					$select.='<option value="'.$rs['erecords_id'].'" selected>'.$rs['fname'].' '.$rs['lname'].'</option>';
				}else{
				$select.='<option value="'.$rs['erecords_id'].'">'.$rs['fname'].' '.$rs['lname'].'</option>';
				}
			}
			$select.='</select>';
			echo $select; ?>
			      <br>
				    <input type="submit" name="submit" value="Edit"/>
		</div>
	</div>
	</form>
</body>
</html>