/*
SQLyog Ultimate v10.42 
MySQL - 5.5.5-10.1.35-MariaDB : Database - bhms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bhms` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bhms`;

/*Table structure for table `announcement` */

DROP TABLE IF EXISTS `announcement`;

CREATE TABLE `announcement` (
  `a_id` int(11) NOT NULL,
  `ad_id` int(11) DEFAULT NULL,
  `at_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `date_posted` datetime DEFAULT NULL,
  `date_expired` datetime DEFAULT NULL,
  PRIMARY KEY (`a_id`),
  KEY `ad_id` (`ad_id`),
  KEY `at_id` (`at_id`),
  CONSTRAINT `announcement_ibfk_1` FOREIGN KEY (`ad_id`) REFERENCES `announcement_details` (`ad_id`),
  CONSTRAINT `announcement_ibfk_2` FOREIGN KEY (`at_id`) REFERENCES `announcement_type` (`at_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `announcement` */

/*Table structure for table `announcement_details` */

DROP TABLE IF EXISTS `announcement_details`;

CREATE TABLE `announcement_details` (
  `ad_id` int(11) NOT NULL,
  `details` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `announcement_details` */

/*Table structure for table `announcement_type` */

DROP TABLE IF EXISTS `announcement_type`;

CREATE TABLE `announcement_type` (
  `at_id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`at_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `announcement_type` */

insert  into `announcement_type`(`at_id`,`type`) values (1,'Urgent'),(2,'Important');

/*Table structure for table `appointment` */

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `apt_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `station_id` int(11) DEFAULT NULL,
  `mtype_id` int(11) DEFAULT NULL,
  `atest_id` int(11) DEFAULT NULL,
  `priority_no` int(5) DEFAULT NULL,
  `apt_date` datetime DEFAULT NULL,
  PRIMARY KEY (`apt_id`),
  KEY `patient_id` (`patient_id`),
  KEY `emp_id` (`emp_id`),
  KEY `station_id` (`station_id`),
  KEY `mtype_id` (`mtype_id`),
  KEY `atest_id` (`atest_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`),
  CONSTRAINT `appointment_ibfk_3` FOREIGN KEY (`station_id`) REFERENCES `station` (`station_id`),
  CONSTRAINT `appointment_ibfk_4` FOREIGN KEY (`mtype_id`) REFERENCES `medication_type` (`mtype_id`),
  CONSTRAINT `appointment_ibfk_5` FOREIGN KEY (`atest_id`) REFERENCES `appointment_test` (`atest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `appointment` */

insert  into `appointment`(`apt_id`,`patient_id`,`emp_id`,`station_id`,`mtype_id`,`atest_id`,`priority_no`,`apt_date`) values (0,1,1,2,2,0,0,'2019-04-01 17:56:58'),(1,2,1,3,1,1,1,'2019-04-02 10:30:04'),(3,1,1,1,1,0,1,'2019-04-02 20:37:55'),(4,5,1,3,3,0,5,'2019-04-02 20:41:13'),(5,5,1,3,3,0,5,'2019-04-02 20:41:27');

/*Table structure for table `appointment_test` */

DROP TABLE IF EXISTS `appointment_test`;

CREATE TABLE `appointment_test` (
  `atest_id` int(11) NOT NULL,
  `ttype_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`atest_id`),
  KEY `ttype_id` (`ttype_id`),
  CONSTRAINT `appointment_test_ibfk_1` FOREIGN KEY (`ttype_id`) REFERENCES `test_type` (`ttype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `appointment_test` */

insert  into `appointment_test`(`atest_id`,`ttype_id`) values (0,1),(1,2);

/*Table structure for table `barangay` */

DROP TABLE IF EXISTS `barangay`;

CREATE TABLE `barangay` (
  `barangay_id` int(11) NOT NULL,
  `bname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`barangay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `barangay` */

insert  into `barangay`(`barangay_id`,`bname`) values (1,'Tablon'),(2,'Agusan'),(3,'Bugo');

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `erecords_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `user_id` (`user_id`),
  KEY `position_id` (`position_id`),
  KEY `erecords_id` (`erecords_id`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`position_id`) REFERENCES `position` (`position_id`),
  CONSTRAINT `employee_ibfk_3` FOREIGN KEY (`erecords_id`) REFERENCES `employee_records` (`erecords_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `employee` */

insert  into `employee`(`emp_id`,`user_id`,`position_id`,`erecords_id`) values (1,1,1,1);

/*Table structure for table `employee_records` */

DROP TABLE IF EXISTS `employee_records`;

CREATE TABLE `employee_records` (
  `erecords_id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `mi` varchar(1) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `gender` enum('m','f') DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_no` varchar(12) DEFAULT NULL,
  `date_hired` datetime DEFAULT NULL,
  PRIMARY KEY (`erecords_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `employee_records` */

insert  into `employee_records`(`erecords_id`,`fname`,`lname`,`mi`,`age`,`gender`,`address`,`contact_no`,`date_hired`) values (1,'Lance','Amil','P',16,'m','cdo','09054972326','2019-03-25 17:15:30'),(2,'John Ruskin','Pil','P',16,'m','cdo','12345','2019-04-02 15:38:34');

/*Table structure for table `medication_medicine` */

DROP TABLE IF EXISTS `medication_medicine`;

CREATE TABLE `medication_medicine` (
  `mmedicine_id` int(11) NOT NULL,
  `med_id` int(11) DEFAULT NULL,
  `stocks_id` int(11) DEFAULT NULL,
  `total_dosage` int(5) DEFAULT NULL,
  `intake_sched` varchar(255) DEFAULT NULL,
  `med_days` int(3) DEFAULT NULL,
  `dosage_unit` varchar(255) DEFAULT NULL,
  `dosage_per_day` int(2) DEFAULT NULL,
  PRIMARY KEY (`mmedicine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `medication_medicine` */

/*Table structure for table `medication_records` */

DROP TABLE IF EXISTS `medication_records`;

CREATE TABLE `medication_records` (
  `mrecords_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `mtype_id` int(11) DEFAULT NULL,
  `mmedicine_id` int(11) DEFAULT NULL,
  `apt_id` int(11) DEFAULT NULL,
  `date_med` datetime DEFAULT NULL,
  `date_nextmed` datetime DEFAULT NULL,
  PRIMARY KEY (`mrecords_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `medication_records` */

/*Table structure for table `medication_type` */

DROP TABLE IF EXISTS `medication_type`;

CREATE TABLE `medication_type` (
  `mtype_id` int(11) NOT NULL,
  `medication_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`mtype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `medication_type` */

insert  into `medication_type`(`mtype_id`,`medication_type`) values (1,'Checkup'),(2,'Prenatal'),(3,'Immunization');

/*Table structure for table `medicine` */

DROP TABLE IF EXISTS `medicine`;

CREATE TABLE `medicine` (
  `med_id` int(11) NOT NULL,
  `medtype_id` int(11) DEFAULT NULL,
  `med_name` varchar(255) DEFAULT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`med_id`),
  KEY `medtype_id` (`medtype_id`),
  CONSTRAINT `medicine_ibfk_1` FOREIGN KEY (`medtype_id`) REFERENCES `medicine_type` (`medtype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `medicine` */

insert  into `medicine`(`med_id`,`medtype_id`,`med_name`,`brand_name`) values (1,2,'BCG',NULL),(2,2,'Hepatitis B Vaccine',NULL),(3,2,'Pentavalent Vaccine',NULL),(4,2,'Oral Polio Vaccine (OPV))',NULL),(5,2,'Inactivated Polio Vaccine (IPV)',NULL),(6,2,'Pneumococcal Conjugate Vaccine (PCV)',NULL),(7,2,'Measles, Mumps, Rubella Vaccine (MMR)',NULL),(8,NULL,NULL,NULL),(9,NULL,NULL,NULL),(10,NULL,NULL,NULL),(11,NULL,NULL,NULL),(12,NULL,NULL,NULL),(13,NULL,NULL,NULL),(14,NULL,NULL,NULL),(15,NULL,NULL,NULL),(16,NULL,NULL,NULL),(17,NULL,NULL,NULL),(18,NULL,NULL,NULL),(19,NULL,NULL,NULL),(20,NULL,NULL,NULL);

/*Table structure for table `medicine_suppliers` */

DROP TABLE IF EXISTS `medicine_suppliers`;

CREATE TABLE `medicine_suppliers` (
  `msupp_id` int(11) NOT NULL,
  `med_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`msupp_id`),
  KEY `med_id` (`med_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `medicine_suppliers_ibfk_1` FOREIGN KEY (`med_id`) REFERENCES `medicine` (`med_id`),
  CONSTRAINT `medicine_suppliers_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `medicine_suppliers` */

/*Table structure for table `medicine_type` */

DROP TABLE IF EXISTS `medicine_type`;

CREATE TABLE `medicine_type` (
  `medtype_id` int(11) NOT NULL,
  `medtype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`medtype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `medicine_type` */

insert  into `medicine_type`(`medtype_id`,`medtype`) values (1,'medicine'),(2,'vaccine');

/*Table structure for table `patient` */

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ptype_id` int(11) DEFAULT NULL,
  `precords_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `user_id` (`user_id`),
  KEY `ptype_id` (`ptype_id`),
  KEY `precords_id` (`precords_id`),
  CONSTRAINT `patient_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `patient_ibfk_2` FOREIGN KEY (`ptype_id`) REFERENCES `patient_type` (`ptype_id`),
  CONSTRAINT `patient_ibfk_3` FOREIGN KEY (`precords_id`) REFERENCES `patient_records` (`precords_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient` */

insert  into `patient`(`patient_id`,`user_id`,`ptype_id`,`precords_id`) values (1,2,1,1),(2,3,1,2),(3,4,1,3),(4,5,1,4),(5,6,1,5),(6,7,1,6),(7,8,1,7),(8,9,1,8),(9,10,1,9),(10,11,1,10),(11,12,1,11),(12,13,1,12),(13,14,1,13),(14,15,1,14),(15,16,1,15),(16,17,1,16),(17,18,1,17),(18,19,1,18),(19,20,1,19),(20,21,1,20),(21,22,1,21),(22,23,1,22),(23,24,1,23),(24,25,1,24),(25,26,1,25),(26,27,1,26),(27,28,1,27),(28,29,1,28),(29,30,1,29),(30,31,1,30),(31,32,1,31),(32,33,1,32),(33,34,1,33),(34,35,1,34),(35,36,1,35),(36,37,1,36),(37,38,1,37),(38,39,1,38),(39,40,1,39),(40,41,1,40),(41,42,1,41),(42,43,1,42),(43,44,1,43),(44,45,1,44),(45,46,1,45),(46,47,1,46),(47,48,1,47),(48,49,1,48),(49,50,1,49);

/*Table structure for table `patient_records` */

DROP TABLE IF EXISTS `patient_records`;

CREATE TABLE `patient_records` (
  `precords_id` int(11) NOT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `mi` varchar(1) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `gender` enum('m','f') DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_no` varchar(12) DEFAULT NULL,
  `birth_date` datetime DEFAULT NULL,
  `birth_place` varchar(255) DEFAULT NULL,
  `mother's_name` varchar(255) DEFAULT NULL,
  `father's_name` varchar(255) DEFAULT NULL,
  `birth_height` float(5,2) DEFAULT NULL,
  `birth_weight` float(5,2) DEFAULT NULL,
  PRIMARY KEY (`precords_id`),
  KEY `zone_id` (`zone_id`),
  CONSTRAINT `patient_records_ibfk_1` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient_records` */

insert  into `patient_records`(`precords_id`,`zone_id`,`fname`,`lname`,`mi`,`age`,`gender`,`address`,`contact_no`,`birth_date`,`birth_place`,`mother's_name`,`father's_name`,`birth_height`,`birth_weight`) values (1,1,'Levin','Mendoza','P',16,'m','cdo',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,'Glenn','Smith','I',20,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,1,'Xavier','Johnson','U',18,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,2,'Musa','Williams','B',25,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,2,'Darren','Brown','A',30,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,3,'Ryan','Jones','A',35,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,3,'Evangeline','Miller','L',17,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,4,'Christian','Davis','N',16,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,5,'Tyler','Garcia','M',20,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,5,'Sienna','Rodriguez','T',25,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,10,'Ariza','Abao-Abao','A',18,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,12,'Engelle','Perocho','B',12,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,1,'Ethan ','Toledo','Q',9,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,5,'Faith','Cainday','W',35,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,7,'Fevelyn','Luna','R',57,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,8,'Gen ','Co','T',24,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,20,'Jane','Palangan','G',57,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,19,'Jb','Gurrea','H',79,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,20,'Je','Poy','J',56,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,1,'Je','Sang','F',30,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,4,'Jessa','Chris','S',31,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,5,'Jezza','Borja','A',43,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,6,'Jissa','Dablio','V',25,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,11,'John','Louie','C',26,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,15,'John','Pil','Z',27,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,17,'Jollo','Erbito','X',28,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,18,'Kai','Delgado','F',23,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,2,'Karl','Ramirez','H',20,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,3,'Kath','Lozada','N',29,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,5,'Keinth','James','M',20,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,6,'Kit','Macahilos','J',19,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,7,'Leslie','Patana','K',18,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,10,'Lloyd','Caayaman','L',16,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,12,'Love','Green','L',15,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,18,'Lovely','Villanueva','U',15,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(36,14,'Michell','Aguilar','Y',9,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,15,'Nikki','Ibaoc','T',5,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,16,'Nore','Pacatang','R',8,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,17,'Pamz','Pamisa','G',17,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(40,13,'Shiela','Golosino','H',14,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(41,11,'Ton','Bayawon','F',18,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(42,10,'Yumah','Jalalon','D',19,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(43,19,'Yves','Arbues','E',20,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(44,20,'Aeron','Martizano','Q',21,'m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(45,11,'Angela','Claridad','F',22,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,1,'Danica','Cruz','G',24,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,2,'Faye','Rebollido','J',26,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(48,6,'Glaiza','Gaid','P',26,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(49,5,'Hannah','Lozano','O',24,'f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `patient_type` */

DROP TABLE IF EXISTS `patient_type`;

CREATE TABLE `patient_type` (
  `ptype_id` int(11) NOT NULL,
  `patient_type` enum('1','2') DEFAULT NULL,
  PRIMARY KEY (`ptype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient_type` */

insert  into `patient_type`(`ptype_id`,`patient_type`) values (1,'1'),(2,'2');

/*Table structure for table `po_details` */

DROP TABLE IF EXISTS `po_details`;

CREATE TABLE `po_details` (
  `pod_id` int(11) NOT NULL,
  `med_id` int(11) DEFAULT NULL,
  `por_id` int(11) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `date_received` datetime DEFAULT NULL,
  PRIMARY KEY (`pod_id`),
  KEY `med_id` (`med_id`),
  KEY `por_id` (`por_id`),
  CONSTRAINT `po_details_ibfk_1` FOREIGN KEY (`med_id`) REFERENCES `medicine` (`med_id`),
  CONSTRAINT `po_details_ibfk_2` FOREIGN KEY (`por_id`) REFERENCES `po_request` (`por_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `po_details` */

/*Table structure for table `po_request` */

DROP TABLE IF EXISTS `po_request`;

CREATE TABLE `po_request` (
  `por_id` int(11) NOT NULL,
  `pos_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `date_req` datetime DEFAULT NULL,
  PRIMARY KEY (`por_id`),
  KEY `pos_id` (`pos_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `po_request_ibfk_1` FOREIGN KEY (`pos_id`) REFERENCES `po_status` (`pos_id`),
  CONSTRAINT `po_request_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `po_request` */

/*Table structure for table `po_status` */

DROP TABLE IF EXISTS `po_status`;

CREATE TABLE `po_status` (
  `pos_id` int(11) NOT NULL,
  `status` enum('received','cancelled','ongoing') DEFAULT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `po_status` */

/*Table structure for table `position` */

DROP TABLE IF EXISTS `position`;

CREATE TABLE `position` (
  `position_id` int(11) NOT NULL,
  `position` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `position` */

insert  into `position`(`position_id`,`position`) values (1,'Admin'),(2,'Barangay Health Worker'),(3,'Barangay Nutrition Scholar'),(4,'Nurse');

/*Table structure for table `station` */

DROP TABLE IF EXISTS `station`;

CREATE TABLE `station` (
  `station_id` int(11) NOT NULL,
  `stname` varchar(255) DEFAULT NULL,
  `is_available` enum('1','0') DEFAULT NULL,
  PRIMARY KEY (`station_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `station` */

insert  into `station`(`station_id`,`stname`,`is_available`) values (1,'Nurse Station','1'),(2,'Prenatal Station','1'),(3,'Test Station','1');

/*Table structure for table `station_assignment` */

DROP TABLE IF EXISTS `station_assignment`;

CREATE TABLE `station_assignment` (
  `sassign_id` int(11) NOT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `station_id` int(11) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  PRIMARY KEY (`sassign_id`),
  KEY `emp_id` (`emp_id`),
  KEY `station_id` (`station_id`),
  CONSTRAINT `station_assignment_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`),
  CONSTRAINT `station_assignment_ibfk_2` FOREIGN KEY (`station_id`) REFERENCES `station` (`station_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `station_assignment` */

/*Table structure for table `stocks` */

DROP TABLE IF EXISTS `stocks`;

CREATE TABLE `stocks` (
  `stocks_id` int(11) NOT NULL,
  `pod_id` int(11) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  PRIMARY KEY (`stocks_id`),
  KEY `pod_id` (`pod_id`),
  CONSTRAINT `stocks_ibfk_1` FOREIGN KEY (`pod_id`) REFERENCES `po_details` (`pod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `stocks` */

/*Table structure for table `suppliers` */

DROP TABLE IF EXISTS `suppliers`;

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_no` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `suppliers` */

/*Table structure for table `test_records` */

DROP TABLE IF EXISTS `test_records`;

CREATE TABLE `test_records` (
  `trecords_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `ttype_id` int(11) DEFAULT NULL,
  `apt_id` int(11) DEFAULT NULL,
  `height` float(5,2) DEFAULT NULL,
  `weight` float(5,2) DEFAULT NULL,
  `bp_higher` int(3) DEFAULT NULL,
  `bp_lower` int(3) DEFAULT NULL,
  `date_test` datetime DEFAULT NULL,
  PRIMARY KEY (`trecords_id`),
  KEY `patient_id` (`patient_id`),
  KEY `ttype_id` (`ttype_id`),
  KEY `apt_id` (`apt_id`),
  CONSTRAINT `test_records_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `test_records_ibfk_2` FOREIGN KEY (`ttype_id`) REFERENCES `test_type` (`ttype_id`),
  CONSTRAINT `test_records_ibfk_3` FOREIGN KEY (`apt_id`) REFERENCES `appointment` (`apt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `test_records` */

/*Table structure for table `test_type` */

DROP TABLE IF EXISTS `test_type`;

CREATE TABLE `test_type` (
  `ttype_id` int(11) NOT NULL,
  `test_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ttype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `test_type` */

insert  into `test_type`(`ttype_id`,`test_type`) values (1,'Blood Pressure'),(2,'BMI');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `access_level` enum('1','2','3') DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`user_id`,`username`,`password`,`access_level`,`status`) values (1,'admin','admin','1',NULL),(2,'glennsmith','123','3',1),(3,'xavierjohnson','123','3',1),(4,'musa','123','3',1),(5,'123','123','3',1),(6,NULL,NULL,'3',NULL),(7,NULL,NULL,'3',NULL),(8,NULL,NULL,'3',NULL),(9,NULL,NULL,'3',NULL),(10,NULL,NULL,'3',NULL),(11,NULL,NULL,'3',NULL),(12,NULL,NULL,'3',NULL),(13,NULL,NULL,'3',NULL),(14,NULL,NULL,'3',NULL),(15,NULL,NULL,'3',NULL),(16,NULL,NULL,'3',NULL),(17,NULL,NULL,'3',NULL),(18,NULL,NULL,'3',NULL),(19,NULL,NULL,'3',NULL),(20,NULL,NULL,'3',NULL),(21,NULL,NULL,'3',NULL),(22,NULL,NULL,'3',NULL),(23,NULL,NULL,'3',NULL),(24,NULL,NULL,'3',NULL),(25,NULL,NULL,'3',NULL),(26,NULL,NULL,'3',NULL),(27,NULL,NULL,'3',NULL),(28,NULL,NULL,'3',NULL),(29,NULL,NULL,'3',NULL),(30,NULL,NULL,'3',NULL),(31,NULL,NULL,'3',NULL),(32,NULL,NULL,'3',NULL),(33,NULL,NULL,'3',NULL),(34,NULL,NULL,'3',NULL),(35,NULL,NULL,'3',NULL),(36,NULL,NULL,'3',NULL),(37,NULL,NULL,'3',NULL),(38,NULL,NULL,'3',NULL),(39,NULL,NULL,'3',NULL),(40,NULL,NULL,'3',NULL),(41,NULL,NULL,'3',NULL),(42,NULL,NULL,'3',NULL),(43,NULL,NULL,'3',NULL),(44,NULL,NULL,'3',NULL),(45,NULL,NULL,'3',NULL),(46,NULL,NULL,'3',NULL),(47,NULL,NULL,'3',NULL),(48,NULL,NULL,'3',NULL),(49,NULL,NULL,'3',NULL),(50,NULL,NULL,'3',NULL),(51,NULL,NULL,'3',NULL);

/*Table structure for table `zone` */

DROP TABLE IF EXISTS `zone`;

CREATE TABLE `zone` (
  `zone_id` int(11) NOT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `zname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`zone_id`),
  KEY `barangay_id` (`barangay_id`),
  CONSTRAINT `zone_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`barangay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `zone` */

insert  into `zone`(`zone_id`,`barangay_id`,`zname`) values (1,1,'Zone 1'),(2,1,'Zone 2'),(3,1,'Zone 3'),(4,1,'Zone 4'),(5,1,'Zone 5'),(6,1,'Zone 6'),(7,1,'Zone 7'),(8,1,'Zone 8'),(9,1,'Zone 9'),(10,1,'Zone 10'),(11,1,'Zone 11'),(12,1,'Zone 12'),(13,1,'Zone 13'),(14,2,'Zone 1'),(15,2,'Zone 2'),(16,2,'Zone 3'),(17,2,'Zone 4'),(18,3,'Zone 1'),(19,3,'Zone 2'),(20,3,'Zone 3');

/*Table structure for table `appointment_view_all` */

DROP TABLE IF EXISTS `appointment_view_all`;

/*!50001 DROP VIEW IF EXISTS `appointment_view_all` */;
/*!50001 DROP TABLE IF EXISTS `appointment_view_all` */;

/*!50001 CREATE TABLE  `appointment_view_all`(
 `Apt No.` int(11) ,
 `Priority No.` int(5) ,
 `Patient Name` varchar(255) ,
 `Employee Name` varchar(255) ,
 `Station` varchar(255) ,
 `Medication Type` varchar(255) ,
 `Date` datetime 
)*/;

/*View structure for view appointment_view_all */

/*!50001 DROP TABLE IF EXISTS `appointment_view_all` */;
/*!50001 DROP VIEW IF EXISTS `appointment_view_all` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `appointment_view_all` AS (select `appointment`.`apt_id` AS `Apt No.`,`appointment`.`priority_no` AS `Priority No.`,`patient_records`.`fname` AS `Patient Name`,`employee_records`.`fname` AS `Employee Name`,`station`.`stname` AS `Station`,`medication_type`.`medication_type` AS `Medication Type`,`appointment`.`apt_date` AS `Date` from ((((((`appointment` join `patient` on((`appointment`.`patient_id` = `patient`.`patient_id`))) join `patient_records` on((`patient_records`.`precords_id` = `patient`.`patient_id`))) join `employee` on((`appointment`.`emp_id` = `employee`.`emp_id`))) join `employee_records` on((`employee`.`erecords_id` = `employee_records`.`erecords_id`))) join `station` on((`appointment`.`station_id` = `station`.`station_id`))) join `medication_type` on((`appointment`.`mtype_id` = `medication_type`.`mtype_id`)))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
