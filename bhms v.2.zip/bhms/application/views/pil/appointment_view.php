


<?php 
	function display_data($data) {
		// var_dump($data);
	    $output = "<table>";
	    foreach($data as $key => $var) {
	        //$output .= '<tr>';
	        if($key===0) {
	            $output .= '<tr>';
	            foreach($var as $col => $val) {
	                $output .= "<td> " . $col . '</td>';
	            }
	            $output .= '</tr>';
	            foreach($var as $col => $val) {
	                $output .= '<td> ' . $val . '</td>';
	            }
	            $output .= '</tr>';
	        }
	        else {
	            $output .= '<tr>';
	            foreach($var as $col => $val) {
	                $output .= '<td> ' . $val . '</td>';
	            }
	            $output .= '</tr>';
	        }
	    }
	    $output .= '</table>';
	    echo $output;
	}
	require 'dbconn.php';
	$query = "SELECT * FROM appointment_view_all ORDER BY `Apt No.` ASC";
	$result = mysqli_query($conn, $query);
	// var_dump($result);
	display_data($result); //display_data ang function nga mag table sa values sa appointment_view_all nga view
 ?>
 <form action="<?= base_url('appointment/showedit');?>" method="post">
<?php 
require "dbconn.php";
$query = "SELECT apt_id FROM appointment ORDER BY apt_id ASC";
$select= '<select name="Apt_ID" id="Apt_ID">';
// $rs= mysqli_query($conn, $query);
$result = mysqli_query($conn, $query);
$i = 0;
while($rs = $result->fetch_assoc()){
	if($i==0){
		$select.='<option value="" selected disabled hidden>
 Select row to edit: </option>';
		$select.='<option value="'.$rs['apt_id'].'">'.$rs['apt_id'].'</option>';
	}
	else{
		$select.='<option value="'.$rs['apt_id'].'">'.$rs['apt_id'].'</option>';
	}
	$i+=1;
}
$select.='</select>';
echo $select; ?>
<input type="submit" name="submit" value="Edit"/>
</form>
<!-- <br> -->
 <form action="<?= base_url('appointment/delete');?>" method="post">
<?php 
require "dbconn.php";
$query = "SELECT apt_id FROM appointment ORDER BY apt_id ASC";
$select= '<select name="Apt_ID" id="Apt_ID">';
// $rs= mysqli_query($conn, $query);
$result = mysqli_query($conn, $query);
$i=0;
while($rs = $result->fetch_assoc()){
	if($i==0){
		$select.='<option value="" selected disabled hidden>
 Select row to delete: </option>';
		$select.='<option value="'.$rs['apt_id'].'">'.$rs['apt_id'].'</option>';
	}
	else{
		$select.='<option value="'.$rs['apt_id'].'">'.$rs['apt_id'].'</option>';
	}
	$i+=1;
}
$select.='</select>';
echo $select; ?>
<input type="submit" name="submit" value="Delete"/>
</form>
<form action="appointment/add">
	<input type="submit" name="submit" value="Create/Add">
</form>