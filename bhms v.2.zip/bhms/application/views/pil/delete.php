
<?php
	require "dbconn.php";
	$AptId = $this->input->post('Apt_ID');
    $Iquery = "DELETE FROM appointment WHERE apt_id=$AptId";
     // echo $Iquery;
    mysqli_query($conn, $Iquery);
     // $result = mysql_query($Iquery);
     // if(mysqli_query($conn, $Iquery)){
     // 	echo "Not Inserted";
     // }
     // else{
     // 	echo "Inserted";
     // }
     // header("refresh:2;url:'localhost/bhms/appointment'");
?>