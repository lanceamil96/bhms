
<?php 
	if($posts!=null){
		foreach($posts as $key) :?>
			<div class="panel body panel-primary">
			<br><h3><?php echo $key->title; ?></h3>
			<small class="post-date">Posted on: <?php echo $key->date_posted; ?></small>
			<br>
			<?php echo $key->details; ?>
			</div>
		<?php endforeach; ?>
<?php
	}
	?>
	
	
