<div class="container-fluid">
	
	<div class="panel">
		<br>
	<div class="container">
		<h4 id="ling">Test</h4>
	
		<form>
	 		<label for="">Blood Pressure</label>
	 		<input type="text" id="bp" name="">
	 		<label for="">Age</label>
	 		<input type="text" id="age" name="">
	 		<label for="">Weight</label>
	 		<input type="text" id="weight" name="">
	 		<label for="">Height</label>
	 		<input type="text" id="height" name=""><br>
	 		<label for="">Sex</label>
	 		<input type="text" id="sex" name="">

		</form>
	</div>
	<br>
	<div class="container1">
		<h4 id="med">Medication Type</h4>
		<a href="#"><input type="button" class="btn btn-primary" value="Immunization"></a>
		<br><br>
		<input type="button" class="btn btn-primary" value="Prenatal">
		<br><br>
		<input type="button" class="btn btn-primary" value="Check-Up">
		


		
	</div>
	<div class="form-group">
			<br>
			<input type="button" class="btn btn-success" value="Submit">
			<br>
		</div>

	</div>	
</div>