<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Announcement extends CI_Model {


	public function read(){
		$this->db->select('*');
		$this->db->from('announcement a');
		$this->db->join('announcement_details b', 'b.ad_id = a.ad_id','left');
		$this->db->join('announcement_type c', 'c.at_id = a.at_id','left');
		$this->db->where('a.status', 1);
		$this->db->order_by('a.a_id','desc');
		
		$query = $this->db->get();
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}
	}

	public function view_post($id = null){
		$this->db->select('*');
		$this->db->from('announcement a');
		$this->db->join('announcement_details b', 'b.ad_id = a.ad_id','left');
		$this->db->join('announcement_type c', 'c.at_id = a.at_id','left');
		$this->db->where('a.ad_id', $id);
		$this->db->order_by('a.a_id','desc');
		$query = $this->db->get();
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}

	
	}

	public function delete_post($id=null){
		$this->db->where('announcement.ad_id', $id);
		$this->db->update('announcement', array('status'=>0));

	}

	public function update_announcement($id, $title, $details, $type){
		$this->db->where('announcement.ad_id', $id);	
		$this->db->update('announcement', array('title'=>$title, 'at_id'=> $type));

		$this->db->where('announcement_details.ad_id', $id);	
		$this->db->update('announcement_details', array('details'=>$details));

		redirect('bhw/go_home');
		
	}
	public function get_types(){
		$this->db->select('*');
		$this->db->from('announcement_type');
		$this->db->order_by('type', 'desc');
		$query = $this->db->get();

		return $query->result_array();
	}


	public function create_announcement(){
		$title = $this->input->post('title');
		$details = $this->input->post('details');
		$type = $this->input->post('type_id');

		$data2 = array(
			'details' => $details
		);

		$this->db->insert('announcement_details', $data2);
		$detail_id = $this->db->insert_id();

		$data1 = array(
			'ad_id' => $detail_id,
			'at_id' => $type,
			'title' => $title		
		);

		return $this->db->insert('announcement', $data1);
		

	}

	





}