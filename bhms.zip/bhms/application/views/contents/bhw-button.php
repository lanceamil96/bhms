<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_reg'); ?>">Register Patient</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_appointment'); ?>">Set Appointment</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_setmedication'); ?>">Set Medication</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_announcement'); ?>">Set Announcement</a>
</li>

<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_inventory'); ?>">View Employees</a>
</li>


<li class="nav-item">
	<a class="nav-link" href="<?= base_url('bhw/go_inventory'); ?>">View Inventory</a>
</li>