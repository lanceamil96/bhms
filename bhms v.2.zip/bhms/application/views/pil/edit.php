
<?php
	require "dbconn.php";
	$AptId = $this->input->post('Apt_Id');
	// echo $AptId;
	$Queue = $this->input->post('Queue');
	$PName = $this->input->post('PName');
	// echo ($PName);
	$Pquery = "SELECT patient_id FROM patient WHERE precords_id=$PName";
	$PId_Query = mysqli_query($conn, $Pquery);
	$PId =  ($PId_Query->fetch_assoc()['patient_id']);
	// echo $PId;
	$Medication = $this->input->post('medication');
	$Station = $this->input->post('station');
	$Test = $this->input->post('test');
	$Staff = $this->input->post('staff');
	$Equery = "SELECT emp_id FROM employee WHERE erecords_id=$Staff";
	$EmpID_Query = mysqli_query($conn, $Equery);
	// echo $Queue.$PName.$Medication.$Station;
	$EmpID =  ($EmpID_Query->fetch_assoc()['emp_id']);
	// INSERT INTO appointment (apt_id,patient_id,emp_id,station_id,mtype_id,atest_id,priority_no,apt_date) VALUES (2,'asd,',1,1,',,2019-04-02 13:52:44')
    // $Iquery = "INSERT INTO appointment (apt_id,patient_id,emp_id,station_id,mtype_id,atest_id,priority_no,apt_date) VALUES ($AptId,$PId,$EmpID,$Station,$Medication,'',$Queue,(SELECT CONVERT(NOW(), DATETIME)))";
    $Iquery = "UPDATE appointment SET apt_id=$AptId,patient_id=$PId,emp_id=$EmpID,station_id=$Station,mtype_id=$Medication,apt_date=(SELECT CONVERT(NOW(), DATETIME)) where apt_id=$AptId";
     // echo $Iquery;
    // mysqli_query($conn, $Iquery);
     // $result = mysql_query($Iquery);
     if(mysqli_query($conn, $Iquery)){
     	echo "Edited";
     }
     else{
     	echo "Not Edited";
     }
     // header("refresh:2;url:'localhost/bhms/appointment'");
?>