
<?php 
	if($posts!=null){
		foreach($posts as $key) :?>
			<div class="panel body panel-primary">
				<br><h3><?php echo $key->title; ?>
				</h3>
				<small class="post-date">Posted on: <?php echo $key->date_posted; ?>  <strong><?= $key->type ?></strong></small>
				<br>
				<div class="details-panel">
					<?php echo word_limiter($key->details,50); ?>
				<br><br>
				</div>
				<br>
				<div class="details-btn">
					<p><a class="btn btn-primary" href="<?php echo base_url('/bhw/view_announcement/'.$key->ad_id );?>
				">Read More</a></p>
					<p><a class="btn btn-info" href="<?php echo base_url('/bhw/go_update_announcement/'.$key->ad_id );?>
					">Update</a></p>
					<p><a class="btn btn-danger" href="<?php echo base_url('/bhw/delete_announcement/'.$key->ad_id );?>
					">Delete</a></p>
				</div>	
				<br><br>
			
			</div>

		<?php endforeach; ?>
<?php
	}
?>


	
	
