<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Staff_model', 'staff');
	}

	public function index(){
		$data['emp'] = $this->staff->getAll();
		$data['button'] = 'contents/bhw-button';
		$this->load->view('templates/staff',$data);
		// $data['users'] = $this->user->read();
		// $data['pagename'] = 'Bhw Dashboard';
		// $data['button'] = 'contents/bhw-button';
		// $data['contents'] = 'contents/bhw';		
		// $this->load->view('templates/bhw', $data);
	}

	public function save_staff()
	{
		if( $_POST ){
			$this->staff->save_staff($_POST);
		}
		
		$data['data'] = $this->staff->getAll();
		die(json_encode($data['data']));
	}

	public function get_info($id)
	{
		$info = $this->staff->get_info($id);
		die(json_encode($info));
	}


}