
<?php echo validation_errors(); ?>
<form action="<?php echo base_url('/bhw/update_announcement/'.$announcement[0]->ad_id );?>">

	<div class="form-group">
		<label>Title</label>
		<input type="text" name="title" required class="form-control" value="<?= $announcement[0]->title ?>">
	</div>
	<div class="form-group">
		<label>Details</label>
		<textarea id="editor1" class="form-control" required name="details" rows="10"><?= $announcement[0]->details ?></textarea>
	</div>

	<div class="form-group">
		<label>Type</label>
		<select name="type_id" class="form-control">
			<?php foreach($type as $type): ?>
				<option value="<?= $type['at_id'];?>"><?= $type['type'];?></option>	
			<?php endforeach ?>
		</select>
	</div>
	
	<button type="submit" class="btn btn-info">Update</button>
	<br><br>
	<script>
         // Replace the <textarea id="editor1"> with a CKEditor
         // instance, using default configuration.
         CKEDITOR.replace( 'editor1' );
    </script>


</form>