<div class="announcement">
<?php 
	if($posts!=null){
		foreach($posts as $key) :?>
			<div class="panel body panel-primary">
				<br>
				
				<h3><?php echo $key->title; ?></h3>
				
				
				<small class="post-date">Posted on: <?php echo $key->date_posted; ?>  <strong><?= $key->type ?></strong></small>
				<br>
				<div class="details-panel">
					<?php echo word_limiter($key->details, 50); ?>
				</div>
				<br><br>
				<br>
				<div class="details-btn">
					<p><a class="btn btn-primary" href="<?php echo base_url('/app/view_announcement/'.$key->ad_id );?>
				">Read More</a></p>
				</div>


			</div>
				

			


			
		<?php endforeach; ?>
<?php
	}
?>

</div>
	
	
