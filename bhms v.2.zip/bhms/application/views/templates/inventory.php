<!DOCTYPE html>
<html>
<head>

</head>
<body>

<ul>
  <!--<li><a href="home.php">Home</a></li> -->
  <li><a href="#purchase">Purchase Request</a></li>
  <li><a href="#stocks">Stocks</a></li>
  <li><a href="#report">Report</a></li>
  <li ><a href="<?= base_url('bhw')?>">Home</a></li>
  <li style="float:right"><a href="<?= base_url('app/logout')?>">Logout</a></li>

</ul>
<div id="home">
  HOME <br/><br/><br/>
</div>
<div id="purchase">
  Purchase Number<input type="text" name="purchase_no" style="margin-left: 20px;">
  Purchase Date<input type="date" name="purchase_date" style="margin-left: 43px;">
  Supplier<input type="text" name="supplier">
  <h1 style="
    ">Purchases Detail</h1>
  <br/>
  <table class="purchase-table">
      <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Quantity</th>
      </tr>
      <tr>
        <td><input type="text"></td>
        <td><input type="text"></td>
        <td><input type="text"></td>
      </tr>
      <tr>
        <td><input type="text"></td>
        <td><input type="text"></td>
        <td><input type="text"></td>
      </tr>
      <tr>
        <td><input type="text"></td>
        <td><input type="text"></td>
        <td><input type="text"></td>
      </tr>
  </table>
  <button class="button">Add</button>
</div>
<br/>
<br/>
<div id="stocks">
<h1 style="title">Stocks</h1>

  <table style="width:100%" class="stocks-table">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Type</th> 
      <th>Description</th>
      <th>Stock In</th>
      <th>Stock Out</th>
    <tr>
      <td>1</td>
      <td>Biogesic
      <td>Medicine</td>
      <td>Panghilanat</td>
      <td>50</td>
      <td>0</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Rexidol</td>
      <td>Medicine</td> 
      <td>Tambal sa pamaol</td>
      <td>50</td>
      <td>0</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Pentavalent Vaccine</td> 
      <td>Vaccine</td>
      <td>Dipterya, Tetano</td>
      <td>50</td>
      <td>0</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Oral Polio Vaccine</td> 
      <td>Vaccine</td>
      <td>Polio</td>
      <td>50</td>
      <td>0</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Inactivated Polio Vaccine</td> 
      <td>Vaccine</td>
      <td>Polio</td>
      <td>50</td>
      <td>0</td>
    </tr>
    <tr>
      <td>6</td>
      <td>Pnuemococcal Conjugate Vaccine</td> 
      <td>Vaccine</td>
      <td>Pulmonia, Meningitis</td>
      <td>50</td>
      <td>0</td>
    </tr>
    <tr>
      <td>7</td>
      <td>Measles, Mumps, Rubella (MMR)</td> 
      <td>Vaccine</td>
      <td>Tigdas, Beke</td>
      <td>50</td>
      <td>0</td>
    </tr>
  </table>

  <div class="input-btm">
    ID<input type="text" name="vaccine_id">
  <!--  Stock In <input type="text" name="stock_in">  -->
    Stock Out <input type="text" name="stock_out">
    <button class="button">Delete</button>
  </div>  
  <!--  <div class="buttons">
      <button class="button">Delete</button>
      <button class="button">Update</button>
      <button class="button">Reset All</button>   
    </div>   -->
</div>
</body>
</html>



<style type="text/css">
/*.title{

}*/
purchase-table table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  background-color: #d9f1ff;
}
purchase-table th{
  padding: 10px;
}
table {
  width: 100%;
}
#purchase{
  padding: 10px;
  margin-left: 80px;
}
#purchase input{
  margin: 15px;
  padding: 6px;
  border: 2px solid #4e73df;
}
#stocks{
  padding: 10px;
  margin-left: 80px;
}
#stocks input{
  margin: 15px;
  padding: 6px;
  border: 2px solid #4e73df;
}
body {
      position: relative; 
      color: #000;
  }
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:#4e73df;
  position: fixed;
  width: 100%;
  margin-left: -24px;
}

li {
  float: left;
  text-decoration: none;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #fff;
  text-decoration: none;
  font-weight: bolder;
}

.active {
  background-color: #fff;
  color: #4e73df;
}
/*stocks table*/
  stocks-table table, th, td {
  border: 1px solid #4e73df;
  border-collapse: collapse;
  padding: 10px;
  color: #000;
  text-align: center;
}
stocks-table th{
  font-weight: bolder;
  color: #fff;
  background-color: c;
  border: 1px solid #fff;
}
.purchase-table{
  margin-bottom: 50px;
}
.btm-title1{
  color: #000;
  font-size: 1em;
  margin-top: 30px;
  margin-left: 50px;
}
.btm-title2{
  color: #000;
  font-size: 1em;
}
.input-btm{
  margin-top: 20px;
  margin-left: 230px;
  color: #000;
}
button{
  margin-right: 50px;
  width: 150px;
  height: 40px;
  color: #fff;
  background-color: #4e73df;
}
.buttons{
  margin-left: 380px;
  margin-top: 20px;
}
</style>