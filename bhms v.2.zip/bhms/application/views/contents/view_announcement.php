<div .class="view-post">
	<?php
	if($announcement!=null){?>
		<div class="panel body panel-primary">
		<br><h3><?php echo $announcement[0]->title; ?></h3>
		<small class="post-date">Posted on: <?php echo $announcement[0]->date_posted; ?></small>
		<br>
		<?php echo $announcement[0]->details; ?>
		</div>
	<?php
		}
	?>
</div>
