<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Appointment_Model extends CI_Model {


	public function __construct(){
		$this->load->database();
	}


	public function getView(){
		$this->db->select('*');
		$this->db->from('appointment_view_all ');
		// $this->db->join('announcement_details b', 'b.ad_id = a.ad_id','left');
		// $this->db->join('announcement_type c', 'c.at_id = a.at_id','left');
		// $this->db->where('a.status', 1);
		$this->db->order_by('\'Apt No.\'','asc');
		$query = $this->db->get();
		// var_dump($query);
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}
	}


	public function getIDtoList(){
		$this->db->select('apt_id');
		$this->db->from('appointment ');
		// $this->db->join('announcement_details b', 'b.ad_id = a.ad_id','left');
		// $this->db->join('announcement_type c', 'c.at_id = a.at_id','left');
		// $this->db->where('a.status', 1);
		$this->db->order_by('apt_id','asc');
		$query = $this->db->get();
		// var_dump($query);
		if($query->num_rows() !=0){
			return $query->result();
		}else
		{
			return false;
		}
	}
}