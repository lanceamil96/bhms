<div class="container">
	<form action="<?= base_url('app/login'); ?>" method="POST">
		<div class="panel-primary">
			<div class="panel-heading text-center">
				<h4><?= $pagename; ?><h4>
			</div>
			
		</div>
	</form>
</div>