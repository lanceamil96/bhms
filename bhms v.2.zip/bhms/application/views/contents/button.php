<li class="nav-item">
	<a class="nav-link" href="<?= base_url('app/go_login'); ?>">Login</a>
</li>