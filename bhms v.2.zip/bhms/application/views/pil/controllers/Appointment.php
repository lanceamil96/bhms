<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Appointment extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Appointment_Model', 'appointment');
	}
	public function index()
	{
		$data['view'] = $this->appointment->getView();
		$data['list'] = $this->appointment->getIDtoList();
		// print_r($data['list']);
		$this->load->view('pil/appointment_view',$data);
	}
	public function add()
	{
		$this->load->view('pil/appointment_add');
	}
	public function insert()
	{
		$this->load->view('pil/insert');
	}
	public function showedit()
	{
		$this->load->view('pil/appointment_edit');
	}
	public function edit()
	{
		$this->load->view('pil/edit');
		// $this->load->view('welcome_message');
	}
	public function delete()
	{
		$this->load->view('pil/delete');
	}
}