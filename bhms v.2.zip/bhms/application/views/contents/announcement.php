
<?php echo validation_errors(); ?>
<?php echo form_open('bhw/go_announcement');  ?>
	<div class="form-group">
		<label>Title</label>
		<input type="text" required name="title" class="form-control" placeholder="Add Title">
	</div>
	<div class="form-group">
		<label>Details</label>
		<textarea id="editor1" required class="form-control" name="details" placeholder="Add Details"></textarea>
	</div>
	<div class="form-group">
		<label>Type</label>
		<select name="type_id" class="form-control">
			<?php foreach($type as $type): ?>
				<option value="<?= $type['at_id'];?>"><?= $type['type'];?></option>	
			<?php endforeach ?>
		</select>
	</div>


	<button type="submit" class="btn btn-success">Submit</button>
	<script>
         // Replace the <textarea id="editor1"> with a CKEditor
         // instance, using default configuration.
         CKEDITOR.replace( 'editor1' );
    </script>

</form>



	