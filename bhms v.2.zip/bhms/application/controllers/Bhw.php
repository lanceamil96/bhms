<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bhw extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Users', 'user');
		$this->load->model('Announcement', 'announce');
	}

	public function index(){

		$this->check_access();
		$data['users'] = $this->user->read();
		$data['pagename'] = 'Bhw Dashboard';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/bhw';		
		$this->load->view('templates/bhw', $data);
	}

	public function go_inventory(){
		$this->check_access();
		$data['pagename'] = 'Inventory';
		$data['button'] = 'contents/bhw-button';
		$this->load->view('templates/inventory', $data);
	}

	public function go_home(){
		$this->check_access();
		$data['posts'] = $this->announce->read();
		$data['pagename'] = 'Home';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/bhw-home';		
		$this->load->view('templates/bhw', $data);
	}

	public function go_immunization(){
		$this->check_access();
		$data['pagename'] = 'Medication';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/immunization';
		$this->load->view('templates/bhw', $data);

	}

	public function go_test(){
		$this->check_access();
		$data['pagename'] = 'Medication';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/test';
		$this->load->view('templates/bhw', $data);

	}


	public function go_reg(){
		$data['pagename'] = 'Register Patient';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/registration';		
		$this->load->view('templates/bhw', $data);
	}

	public function go_announcement(){	
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('details', 'Details', 'required');
		if($this->form_validation->run() == FALSE){
			$data['type'] = $this->announce->get_types();
			$data['pagename'] = 'Announcements';
			$data['button'] = 'contents/bhw-button';
			$data['contents'] = 'contents/announcement';		
			$this->load->view('templates/bhw', $data);
		}else{

			$this->announce->create_announcement();

			redirect('bhw');
		}
		
	}


	public function view_announcement($id = null){
		$this->check_access();
		$data['announcement'] = $this->announce->view_post($id);
		$data['pagename'] = 'Home';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/view_announcement';		
		$this->load->view('templates/bhw', $data);
	
	}

	public function go_update_announcement($id =null){
		$data['type'] = $this->announce->get_types();
		$data['announcement'] = $this->announce->view_post($id);
		$data['pagename'] = 'Bhw Dashboard';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/update_announcement';		
		$this->load->view('templates/bhw', $data);	
		
		
	}

	public function update_announcement($id=null){
	
		$title =  $this->input->get('title');
		$details =  $this->input->get('details');
		$type_id = $this->input->get('type_id');
		$ad_id = $id;

		$this->announce->update_announcement($ad_id,$title,$details,$type_id);

		
	}

	

	public function delete_announcement($id=null){
		$this->check_access();
		$this->announce->delete_post($id);

		$data['posts'] = $this->announce->read();
		$data['pagename'] = 'Bhw Dashboard';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/bhw-home';		
		$this->load->view('templates/bhw', $data);

	}

	

	private function check_access(){
		if($this->session->has_userdata('logged_in')){
			if($this->session->userdata('access_level') == 2){
				return true;
			}
			else{
				redirect('app');
			}
	    }else{
	    	redirect('app');
	    }
    }







	



}