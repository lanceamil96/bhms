<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Users', 'user');
		$this->load->model('Announcement', 'announce');
	}

	public function index(){

		$this->check_access();
		$data['users'] = $this->user->read();
		$data['pagename'] = 'Dashboard';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/bhw';		
		$this->load->view('templates/admin', $data);
	}

	public function go_home(){
		$this->check_access();
		$data['posts'] = $this->announce->read();
		$data['pagename'] = 'Home';
		$data['button'] = 'contents/bhw-button';
		$data['contents'] = 'contents/home';		
		$this->load->view('templates/admin', $data);
	}

	private function check_access(){
		if($this->session->has_userdata('logged_in')){
			if($this->session->userdata('access_level') == 1){
				return true;
			}
			else{
				redirect('app');
			}
	    }else{
	    	redirect('app');
	    }
    }


	



}