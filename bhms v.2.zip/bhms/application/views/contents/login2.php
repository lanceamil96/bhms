<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	
	<link rel="stylesheet" type="text/css" href="<?= base_url('assests/plugins/bootstrap/css/bootstrap.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assests/plugins/bootstrap/css/bootstrap-theme.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assests/css/style.css'); ?>">
	<link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" rel="stylesheet">
</head>

<body>
		<div class="container alert1">
			
		</div>

		<br>

		<div class="container">
			<form method="post" action="<?php echo base_url(); ?>main/login_validation">
					<div class="form-group has-feedback">
						<label>Enter Username</label>
						<i class="far fa-user-circle"></i><input type="text" placeholder="Username"  class="form-control"/>
					</div>
					<div class="form-group">
						<label>Enter Password</label>
						<i class="fas fa-lock"></i><input type="Password" placeholder="Password"  class="form-control" />
					</div>
					<div class="form-group">
						<br>
						<button type="button" class="btn btn-primary">Login</button>
					</div>
			</form>
		</div>
		
</body>
</html> 