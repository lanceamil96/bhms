

<!DOCTYPE html>
<html>
<head>
	<title>Appointment</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">

  <script src="assets/js/jquery-1.10.1.min.js"></script>
  <script src="assets/js/bootstrap.min.js" ></script>
  

	<style>
	

	img {float: left; margin-top: 0px; padding-top: 0px;}

	h1   {text-align: center; padding-left: 0px; margin-right: 180px; margin-top: 50px;}
	.form-group{padding: 15px; font-size: 20px; }
	#QueueInput {margin-left: 990px;}
	#submit {margin-left: 1100px; padding: 10px;}
</style>
</head>
<body>

	<form role="form" action="insert" method="post">
	<div>
		<h1>Add Appointment</h1><br><br>

		<div id="QueueInput">
			
				Queue
				<input  required type="text" id="Queue"name="Queue"><br>
			
		</div>

		<div class= "form-group">
			<label>Patient Name:</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT * FROM patient_records";
			$select= '<select name="PName" id="PName">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				$select.='<option value="'.$rs['precords_id'].'">'.$rs['fname'].' '.$rs['lname'].'</option>';
			}
			$select.='</select>';
			echo $select; ?>
			<br>
			<!-- Medication Select Input -->
			<label for="sel1">Medication:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT * FROM medication_type";
			$select= '<select name="medication" id="medication">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				$select.='<option value="'.$rs['mtype_id'].'">'.$rs['medication_type'].'</option>';
			}
			$select.='</select>';
			echo $select; ?>
			<br>

			

			 <!-- Station Select Input -->
			<label for="sel2">Station:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT station_id,stname FROM station";
			$select= '<select name="station" id="station">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				$select.='<option value="'.$rs['station_id'].'">'.$rs['stname'].'</option>';
			}
			$select.='</select>';
			echo $select; ?>
			      <br>

			<!-- Test Select Input -->
			<label for="sel3">Test:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT * FROM test_type";
			$select= '<select name="Test" id="Test">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				$select.='<option value="'.$rs['ttype_id'].'">'.$rs['test_type'].'</option>';
			}
			$select.='</select>';
			echo $select; ?>
	<hr>

			  <!-- Station Select Input -->
			<label for="sel4">Assigned Staff:
			</label>
			<?php 
			require "dbconn.php";
			$query = "SELECT erecords_id,fname,lname FROM employee_records";
			$select= '<select name="staff" id="staff">';
			// $rs= mysqli_query($conn, $query);
			$result = mysqli_query($conn, $query);
			while($rs = $result->fetch_assoc()){
				$select.='<option value="'.$rs['erecords_id'].'">'.$rs['fname'].' '.$rs['lname'].'</option>';
			}
			$select.='</select>';
			echo $select; ?>
			      <br>
				    <input type="submit" name="submit" value="Submit"/>
		</div>
	</div>
	</form>
</body>
</html>