<div class="container-fluid">
	<h4 id="bhmis">Barangay HealthCare Management Information System</h4>
	<hr>
	<div class="panel">
		<br>
		<table>
  <tr>
    <th>BAKUNA</th>
    <th>DOSES</th>
    <th>PETSA NG BAKUNA</th>
    <th>REMARKS</th>
  </tr>
  <tr>
    <td id="taas">BCG</td>
    <td><form><input type="text" name=""></form></td>
    <td><form><input type="text" placeholder=" mm| dd | yyyy " name=""></form></td>
    <td><form><input type="text" name=""></form></td>
  </tr>
  <tr>
    <td id="taas">HEPATITS B</td>
    <td><form><input type="text" name=""></form></td>
    <td><form><input type="text" placeholder=" mm| dd | yyyy " name=""></form></td>
    <td><form><input type="text" name=""></form></td>
  </tr>
  <tr>
    <td id="taas">PENTAVALENT VACCINE</td>
    <td><form><input type="text" name=""></form></td>
    <td><form><input type="text" placeholder=" mm| dd | yyyy " name=""></form></td>
    <td><form><input type="text" name=""></form></td>
  </tr>
  <tr>
    <td id="taas">ORAL POLIO VACCINE</td>
    <td><form><input type="text" name=""></form></td>
    <td><form><input type="text" placeholder=" mm| dd | yyyy " name=""></form></td>
    <td><form><input type="text" name=""></form></td>
  </tr>
  <tr>
    <td id="taas">INACTIVATED POLIO VACCINE</td>
    <td><form><input type="text" name=""></form></td>
    <td><form><input type="text" placeholder=" mm| dd | yyyy " name=""></form></td>
    <td><form><input type="text" name=""></form></td>
  </tr>
  <tr>
    <td id="taas">PNEUMOCOCCAL CONJUGATE VACCINE</td>
    <td><form><input type="text" name=""></form></td>
    <td><form><input type="text" placeholder=" mm| dd | yyyy " name=""></form></td>
    <td><form><input type="text" name=""></form></td>
  </tr>
  <tr>
    <td id="taas">MEASLES,MUMPS,RUBELLA</td>
    <td><form><input type="text" name=""></form></td>
    <td><form><input type="text" placeholder=" mm| dd | yyyy " name=""></form></td>
    <td><form><input type="text" name=""></form></td>
</tr>
</table>

