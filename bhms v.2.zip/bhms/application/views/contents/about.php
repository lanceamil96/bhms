<h4>About</h4>

<p>	Barangay Health Care Management System is designed to provide a quicker and more systematic way to record the medical information of the patients. Its goal is to provide first aid, maternal and child health care, diagnosis of social diseases, and other basic health services to all the members of the community it is serving in a systematic way.</p>